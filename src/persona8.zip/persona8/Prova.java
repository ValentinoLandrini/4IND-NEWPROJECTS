package persona8;

/**
 *
 * @author valentino.landrini
 */
public class Prova {

    public static void main(String[] args) throws Exception {
        Persona8 p8 = new Persona8(181.1, "Landrini", "Valentino", 56f, "19/08/2004", "Vlanein1", "valentinolandrini@gmail.com");

        String info = p8.info();
        
        
        System.out.println("informazioni\n" + info);
                
                
    }
}
